package com.leadtorev.sambhav;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

	public static void main(String[] args) 
	{
     Product p1=new Product("1","AC","Cooling",200000);
     Configuration cfg=new Configuration();
     cfg.configure("NewFile.xml");
     SessionFactory factory = cfg.buildSessionFactory();
     Session ses = factory.openSession();
     Transaction tr = ses.beginTransaction();
     
     ses.persist(p1);
     
     tr.commit();
     
     ses.close();
     
     

	}

}
